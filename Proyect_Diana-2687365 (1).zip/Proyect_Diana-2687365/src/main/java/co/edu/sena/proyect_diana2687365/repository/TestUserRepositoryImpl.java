package co.edu.sena.proyect_diana2687365.repository;
import model.User;

import java.sql.SQLException;


public class TestUserRepositoryImpl {
    public static void main(String[] args) throws SQLException {
        Repository<User> repository = new UserRepositoryImpl();

        System.out.println("========saveObj Insert===========");
        User userInsert1 = new User();
        userInsert1.setUser_fistname("Diana");
        userInsert1.setUser_lastname("Fandiño");
        userInsert1.setUser_email("Diana1214@mail.com");
        userInsert1.setUser_password("Diana12");
        repository.saveObj(userInsert1);

        User userInsert2 = new User();
        userInsert2.setUser_fistname("Nicol");
        userInsert2.setUser_lastname("Torres");
        userInsert2.setUser_email("NicolTorres@mail.com");
        userInsert2.setUser_password("Tores12");
        repository.saveObj(userInsert2);


        System.out.println("========== listaObj =========");
        repository.listAllObj().forEach(System.out::println);
        System.out.println();

        System.out.println("========== byIdObj ===========");
        System.out.println(repository.byIdObj(1));
        System.out.println();

        System.out.println("============== saveObj ===========");
        User userUpdate = new User();
        userUpdate.setUser_fistname("Samuel");
        userUpdate.setUser_lastname("Herrera");
        userUpdate.setUser_email("Samu15@mail.com");
        userUpdate.setUser_password("Samu15");
        repository.listAllObj().forEach(System.out::println);
        System.out.println();

        System.out.println("========== deleteObj ============");
        repository.deleteObj(2);
        repository.listAllObj().forEach(System.out::println);

    }
}

